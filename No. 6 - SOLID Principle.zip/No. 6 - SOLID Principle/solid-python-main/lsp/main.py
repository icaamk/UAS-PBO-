from penguin import Penguin
from eagle import Eagle

eagle = Eagle()
eagle.fly()

penguin = Penguin()
penguin.swim()

