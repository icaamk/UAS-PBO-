from swimming_bird import SwimmingBird

class Penguin(SwimmingBird):
    
    def swim(self):
        print("Penguin swim to the ocean")



