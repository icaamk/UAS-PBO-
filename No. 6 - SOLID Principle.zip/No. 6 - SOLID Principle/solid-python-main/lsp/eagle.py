from flying_bird import FlyingBird

class Eagle(FlyingBird):
    
    def fly(self):
        print("Eagle fly to the sky")
        

