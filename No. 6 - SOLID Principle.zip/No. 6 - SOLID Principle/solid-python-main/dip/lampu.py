from barang_elektronik import BarangElektronik

class Lampu(BarangElektronik):
    
    def beroperasi(self):
        print("Lampu menyala")
        
    def berhenti(self):
        print("Lampu berhenti menyala")




