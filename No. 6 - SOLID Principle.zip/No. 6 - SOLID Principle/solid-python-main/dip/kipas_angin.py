from barang_elektronik import BarangElektronik


class KipasAngin(BarangElektronik):
    
    def beroperasi(self):
        print("Kipas angin berputar")
    
    def berhenti(self):
        print("Kipas angin berhenti berputar")



