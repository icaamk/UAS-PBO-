from abc import ABC

class PembeliOperation(ABC):
    
    def memesan_pesanan(self) -> None:
        pass



