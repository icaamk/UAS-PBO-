<?php
$conn = mysqli_connect('localhost','root','','pbotabel');
if(!$conn){
    echo 'Gagal terhubung';
    
}
?>